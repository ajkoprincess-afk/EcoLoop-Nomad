# EcoLoop Nomad prototype

## Run it
Open `index.html` in a modern browser. No build step or dependencies are required.

## Included
- Responsive Home, Book, AI Travel Planner, Clean Check AI, EcoPoints and Profile screens
- Demo yurt listings with default price ₸50,000 per night
- Booking date validation and local demo reservation requests
- Rule-based itinerary generator with budget breakdown
- Clean Check upload flow for Quick Scan, Detailed Audit and Before & After modes
- EcoPoints balance, activity logging, rewards redemption, badges and history
- Browser-local persistence with localStorage
- Dark mode

## Important limitations
This is a front-end prototype. Clean Check intentionally does not claim to analyze the actual contents of uploaded images: no vision AI API is connected. AI trip planning uses demo rules and illustrative cost estimates. Yurt availability, map routing, weather, payments and partner vouchers are not connected to live services. Data is stored only in the current browser.
